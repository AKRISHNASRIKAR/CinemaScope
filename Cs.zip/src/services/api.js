
import axios from "axios";
import {  POPULAR_API_URL,  UPCOMING_API_URL,  TOPRATED_API_URL,  NOWPLAYING_API_URL,} from "../constants/constant";

const API_BASE_URL = "https://api.themoviedb.org/3";
const API_KEY = "4e44d9029b1270a757cddc766a1bcb63";

export const getMovies = async (type) => {
  try {
    let url;
    switch (type) {
      case "popular":
        url = POPULAR_API_URL;
        break;
      case "upcoming":
        url = UPCOMING_API_URL;
        break;
      case "toprated":
        url = TOPRATED_API_URL;
        break;
      case "nowplaying":
        url = NOWPLAYING_API_URL;
        break;
      default:
        throw new Error("Invalid movie type");
    }

    const response = await axios.get(url);
    return response.data.results;
  } catch (error) {
    console.error(`Error fetching ${type} movies:`, error);
    throw error;
  }

}
  export const getMovieDetails = async (id) => {
    try {
      const response = await axios.get(`${API_BASE_URL}/movie/${id}`, {
        params: {
          api_key: API_KEY,
        },
      });
      return response.data;
    } catch (error) {
      console.error(`Error fetching details for movie ID ${id}:`, error);
      throw error;
    }
}
    export const getMovieCertification = async (movieId) => {
        try {
            const url = `https://api.themoviedb.org/3/movie/${movieId}/release_dates?api_key=YOUR_API_KEY`;
            const response = await axios.get(url);
    
            // Find certification for the US region (or any preferred region)
            const usCert = response.data.results.find((item) => item.iso_3166_1 === "US");
    
            // Return the certification (if available)
            return usCert?.release_dates[0]?.certification || "N/A";
        } catch (error) {
            console.error("Error fetching movie certification:", error);
            return "N/A"; // Return "N/A" if there's an error
        }
    
};
